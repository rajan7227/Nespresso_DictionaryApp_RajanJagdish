// Getting DOM elements
const form = document.getElementById('searchForm');
const input = document.getElementById('wordInput');
const resultsDiv = document.getElementById('results');

// Form submission handler
form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const searchWord = input.value.trim();
    
    // Check if the input field is empty
    if (!searchWord) {
        showError('Please enter a word');
        return;
    }
    
    // Show loading state
    resultsDiv.innerHTML = '<p>Searching...</p>';
    
    try {
        // Fetch data from API
        const response = await fetch(
            `https://api.dictionaryapi.dev/api/v2/entries/en/${searchWord}`
        );
        
        // Handle errors
        if (!response.ok) {
            throw new Error(response.status === 404 
                ? 'Word not found in dictionary' 
                : 'Failed to fetch definition');
        }
        
        // Process successful response
        const data = await response.json();
        console.log(data[0]);
        displayResults(data[0]); // Display first result
        

        // Clear the input field after successful search
        input.value = '';
        
    } catch (error) {
        showError(error.message);
    }
});

// Display results function
function displayResults(wordData) {
    let html = `
        <h2>${wordData.word}</h2>
        <p class="phonetic">${wordData.phonetic || ''}</p>
    `;
    
    // Add audio button if available
    const audioObj = wordData.phonetics.find(p => p.audio);
    if (audioObj && audioObj.audio) {
        html += `
            <button class="audio-btn" onclick="playAudio('${audioObj.audio}')">
                🔊 Play Pronunciation
            </button>
        `;
    }
    
    // Add meanings and definitions
    wordData.meanings.forEach(meaning => {
        html += `
            <div class="meaning">
                <h3>${meaning.partOfSpeech}</h3>
                <ol>
                    ${meaning.definitions.slice(0, 3).map(def => `
                        <li>
                            ${def.definition}
                            ${def.example ? `<div class="example">Example: ${def.example}</div>` : ''}
                        </li>
                    `).join('')}
                </ol>
            </div>
        `;
    });
    
    resultsDiv.innerHTML = html;
}

// Error display function
function showError(message) {
    resultsDiv.innerHTML = `<div class="error">${message}</div>`;
}

// Global function for audio playback
window.playAudio = function(audioUrl) {
    new Audio(audioUrl).play();
};