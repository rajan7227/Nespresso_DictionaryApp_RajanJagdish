# Dictionary App

A simple word lookup tool.

## How to use:
1. Extract the ZIP file
2. Open index.html in any browser
3. Type a word and press Enter

Files included:
- index.html (main page)
- styles.css (design)
- script.js (functionality)
